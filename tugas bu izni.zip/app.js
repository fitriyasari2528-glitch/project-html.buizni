/* ---------- penyimpanan: localStorage, fallback ke memori ---------- */
const store=(()=>{let mem={},ok=false;try{localStorage.setItem('__t','1');localStorage.removeItem('__t');ok=true}catch(e){}
 return{persistent:ok,
  get(k,d){try{const v=ok?localStorage.getItem(k):mem[k];return v?JSON.parse(v):d}catch(e){return d}},
  set(k,v){const s=JSON.stringify(v);if(ok){try{localStorage.setItem(k,s)}catch(e){mem[k]=s}}else mem[k]=s},
  del(k){if(ok){try{localStorage.removeItem(k)}catch(e){}}delete mem[k]}}})();

const K={users:'ksr_users',session:'ksr_session',products:'ksr_products',customers:'ksr_customers',sales:'ksr_sales',settings:'ksr_settings',seeded:'ksr_seeded'};
const QUESTIONS=['Nama hewan peliharaan pertama Anda?','Nama sekolah dasar Anda?','Kota tempat Anda lahir?','Nama panggilan masa kecil Anda?','Makanan favorit Anda?'];
const n=v=>{const x=Number(String(v==null?'':v).replace(/[^\d.-]/g,''));return isFinite(x)?x:0};
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const pad2=x=>String(x).padStart(2,'0');
const ymd=d=>d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());
async function hash(s){try{const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode('kasirku:'+s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}catch(e){let h=5381;for(const c of 'kasirku:'+s)h=((h<<5)+h+c.charCodeAt(0))>>>0;return'f'+h}}

function app(){return{
 persistent:store.persistent,
 user:null,page:'kasir',authTab:'masuk',authMsg:{type:'',text:''},showPw:false,
 lf:{username:'',password:''},
 rf:{name:'',username:'',password:'',q:QUESTIONS[0],a:''},
 ff:{step:1,username:'',q:'',a:'',password:''},
 questions:QUESTIONS,methods:['Tunai','QRIS','Transfer bank','E-wallet'],
 products:[],customers:[],sales:[],settings:{},sf:{},
 q:'',cat:'',cart:[],customerId:'',discount:'',method:'Tunai',paid:'',nowText:'',
 pq:'',pf:{},pm:false,cq:'',cf:{},cm:false,formErr:'',
 hq:'',hd:'',rcpt:null,period:'7',
 pw:{old:'',neu:''},pwMsg:{type:'',text:''},
 dlg:{open:false,text:'',ok:null,btn:'Hapus'},toastMsg:'',toastType:'',_tt:null,
 loading:false,progress:0,_lt:null,
 n,

 /* ---------- init ---------- */
 init(){
  this.startLoad();
  this.products=store.get(K.products,[]);this.customers=store.get(K.customers,[]);this.sales=store.get(K.sales,[]);
  this.settings=store.get(K.settings,{storeName:'Toko Saya',address:'Jl. Contoh No. 1',phone:'',tax:0,footer:'Terima kasih sudah berbelanja'});
  if(!store.get(K.seeded,false)&&!this.products.length){
   const s=(sku,name,category,cost,price,stock)=>({id:uid(),sku,name,category,cost,price,stock,min:10});
   this.products=[s('BRG-001','Mie instan goreng','Makanan',2800,3500,120),s('BRG-002','Air mineral 600 ml','Minuman',2500,4000,80),s('BRG-003','Teh kemasan botol','Minuman',3500,5000,48),s('BRG-004','Kopi sachet','Minuman',1500,2000,150),s('BRG-005','Roti tawar','Makanan',12500,16000,20),s('BRG-006','Gula pasir 1 kg','Sembako',14000,17000,30),s('BRG-007','Minyak goreng 1 L','Sembako',16000,19500,25),s('BRG-008','Telur 1/2 kg','Sembako',13000,15500,6)];
   this.persist();store.set(K.seeded,true);
  }
  this.sf={...this.settings};
  const sid=store.get(K.session,null);
  if(sid){const u=store.get(K.users,[]).find(x=>x.id===sid);if(u)this.user={id:u.id,name:u.name,username:u.username}}
  this.tick();setInterval(()=>this.tick(),30000);
  setTimeout(()=>this.endLoad(),600);
 },
 tick(){this.nowText=this.fmtDate(new Date().toISOString())},
 persist(){store.set(K.products,this.products);store.set(K.customers,this.customers);store.set(K.sales,this.sales);store.set(K.settings,this.settings)},

 /* ---------- util ---------- */
 startLoad(){clearInterval(this._lt);this.loading=true;this.progress=8;
  this._lt=setInterval(()=>{this.progress=Math.min(90,this.progress+Math.random()*14)},120)},
 endLoad(){clearInterval(this._lt);this.progress=100;
  setTimeout(()=>{this.loading=false;setTimeout(()=>{if(!this.loading)this.progress=0},300)},250)},
 go(p){if(p===this.page)return;this.startLoad();setTimeout(()=>{this.page=p;this.endLoad()},300)},
 rp(v){return'Rp '+Math.round(n(v)).toLocaleString('id-ID')},
 fmtDate(iso){return new Date(iso).toLocaleString('id-ID',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'})},
 toast(msg,type=''){this.toastMsg=msg;this.toastType=type;clearTimeout(this._tt);this._tt=setTimeout(()=>this.toastMsg='',2600)},
 ask(text,ok,btn='Hapus'){this.dlg={open:true,text,ok,btn}},
 confirmYes(){const f=this.dlg.ok;this.dlg.open=false;if(f)f()},
 download(name,content,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type}));a.download=name;document.body.appendChild(a);a.click();a.remove()},

 /* ---------- auth ---------- */
 setTab(t){this.authTab=t;this.authMsg={type:'',text:''};this.ff={step:1,username:'',q:'',a:'',password:''}},
 err(t){this.authMsg={type:'err',text:t}},
 async register(){
  const f=this.rf,name=f.name.trim(),un=f.username.trim().toLowerCase(),a=f.a.trim().toLowerCase();
  if(name.length<2)return this.err('Nama lengkap minimal 2 karakter.');
  if(!/^[a-z0-9_.]{3,20}$/.test(un))return this.err('Username 3 sampai 20 karakter: huruf kecil, angka, titik, atau garis bawah.');
  if(f.password.length<6)return this.err('Kata sandi minimal 6 karakter.');
  if(a.length<2)return this.err('Jawaban pertanyaan keamanan wajib diisi.');
  const users=store.get(K.users,[]);
  if(users.some(u=>u.username===un))return this.err('Username sudah dipakai. Coba username lain.');
  const u={id:uid(),name,username:un,pass:await hash(f.password),q:f.q,a:await hash(a),createdAt:new Date().toISOString()};
  users.push(u);store.set(K.users,users);store.set(K.session,u.id);
  this.user={id:u.id,name:u.name,username:u.username};this.page='kasir';
  this.rf={name:'',username:'',password:'',q:QUESTIONS[0],a:''};this.authMsg={type:'',text:''};
 },
 async login(){
  const un=this.lf.username.trim().toLowerCase(),u=store.get(K.users,[]).find(x=>x.username===un);
  if(!u||u.pass!==await hash(this.lf.password))return this.err('Username atau kata sandi salah.');
  store.set(K.session,u.id);this.user={id:u.id,name:u.name,username:u.username};this.page='kasir';
  this.lf={username:'',password:''};this.authMsg={type:'',text:''};
 },
 logout(){store.del(K.session);this.user=null;this.cart=[];this.authTab='masuk';this.authMsg={type:'',text:''}},
 findQuestion(){
  const un=this.ff.username.trim().toLowerCase(),u=store.get(K.users,[]).find(x=>x.username===un);
  if(!u)return this.err('Username tidak ditemukan.');
  this.authMsg={type:'',text:''};this.ff.q=u.q;this.ff.step=2;
 },
 async resetPassword(){
  const users=store.get(K.users,[]),un=this.ff.username.trim().toLowerCase(),u=users.find(x=>x.username===un);
  if(!u)return this.err('Username tidak ditemukan.');
  if(u.a!==await hash(this.ff.a.trim().toLowerCase()))return this.err('Jawaban keamanan tidak cocok.');
  if(this.ff.password.length<6)return this.err('Kata sandi baru minimal 6 karakter.');
  u.pass=await hash(this.ff.password);store.set(K.users,users);
  this.lf={username:un,password:''};this.authTab='masuk';this.ff={step:1,username:'',q:'',a:'',password:''};
  this.authMsg={type:'ok',text:'Kata sandi berhasil diubah. Silakan masuk.'};
 },
 async changePassword(){
  const users=store.get(K.users,[]),u=users.find(x=>x.id===this.user.id);
  if(!u||u.pass!==await hash(this.pw.old))return this.pwMsg={type:'err',text:'Sandi saat ini salah.'};
  if(this.pw.neu.length<6)return this.pwMsg={type:'err',text:'Sandi baru minimal 6 karakter.'};
  u.pass=await hash(this.pw.neu);store.set(K.users,users);this.pw={old:'',neu:''};this.pwMsg={type:'ok',text:'Kata sandi berhasil diganti.'};
 },

 /* ---------- produk (CRUD) ---------- */
 get categories(){return[...new Set(this.products.map(p=>p.category).filter(Boolean))].sort()},
 get filteredProducts(){const k=this.q.trim().toLowerCase();return this.products.filter(p=>(!this.cat||p.category===this.cat)&&(!k||p.name.toLowerCase().includes(k)||p.sku.toLowerCase().includes(k))).sort((a,b)=>a.name.localeCompare(b.name))},
 get productList(){const k=this.pq.trim().toLowerCase();return this.products.filter(p=>!k||p.name.toLowerCase().includes(k)||p.sku.toLowerCase().includes(k)||(p.category||'').toLowerCase().includes(k)).sort((a,b)=>a.name.localeCompare(b.name))},
 nextSku(){let i=this.products.length+1,s;do{s='BRG-'+String(i++).padStart(3,'0')}while(this.products.some(p=>p.sku===s));return s},
 openProduct(p){this.pf=p?{...p}:{id:null,sku:'',name:'',category:'',cost:'',price:'',stock:'',min:5};this.formErr='';this.pm=true},
 saveProduct(){
  const f=this.pf,name=(f.name||'').trim(),price=n(f.price),cost=n(f.cost),stock=Math.floor(n(f.stock)),min=Math.floor(n(f.min));
  if(!name)return this.formErr='Nama barang wajib diisi.';
  if(price<=0)return this.formErr='Harga jual harus lebih dari 0.';
  if(cost<0||stock<0||min<0)return this.formErr='Harga beli, stok, dan batas stok tidak boleh negatif.';
  let sku=(f.sku||'').trim().toUpperCase();if(!sku)sku=this.nextSku();
  if(this.products.some(p=>p.sku===sku&&p.id!==f.id))return this.formErr='Kode barang sudah dipakai barang lain.';
  const d={id:f.id||uid(),sku,name,category:(f.category||'').trim(),cost,price,stock,min};
  this.products=f.id?this.products.map(p=>p.id===f.id?d:p):[d,...this.products];
  this.persist();this.pm=false;this.toast(f.id?'Perubahan disimpan':'Barang ditambahkan');
 },
 deleteProduct(p){this.ask('Hapus barang "'+p.name+'"? Riwayat transaksi lama tidak ikut terhapus.',()=>{
  this.products=this.products.filter(x=>x.id!==p.id);this.cart=this.cart.filter(c=>c.id!==p.id);this.persist();this.toast('Barang dihapus')})},

 /* ---------- pelanggan (CRUD) ---------- */
 get customerList(){const k=this.cq.trim().toLowerCase();return this.customers.filter(c=>!k||c.name.toLowerCase().includes(k)||(c.phone||'').includes(k)).sort((a,b)=>a.name.localeCompare(b.name))},
 spent(id){return this.sales.filter(s=>s.customerId===id).reduce((t,s)=>t+s.total,0)},
 openCustomer(c){this.cf=c?{...c}:{id:null,name:'',phone:'',address:''};this.formErr='';this.cm=true},
 saveCustomer(){
  const f=this.cf,name=(f.name||'').trim(),phone=(f.phone||'').trim();
  if(!name)return this.formErr='Nama pelanggan wajib diisi.';
  if(phone&&!/^[0-9+\-\s]{8,16}$/.test(phone))return this.formErr='Nomor HP tidak valid.';
  const d={id:f.id||uid(),name,phone,address:(f.address||'').trim()};
  this.customers=f.id?this.customers.map(c=>c.id===f.id?d:c):[d,...this.customers];
  this.persist();this.cm=false;this.toast(f.id?'Perubahan disimpan':'Pelanggan ditambahkan');
 },
 deleteCustomer(c){this.ask('Hapus pelanggan "'+c.name+'"?',()=>{
  this.customers=this.customers.filter(x=>x.id!==c.id);if(this.customerId===c.id)this.customerId='';this.persist();this.toast('Pelanggan dihapus')})},

 /* ---------- kasir ---------- */
 get cartItems(){return this.cart.map(c=>{const p=this.products.find(x=>x.id===c.id);return p?{...p,qty:c.qty}:null}).filter(Boolean)},
 get subtotal(){return this.cartItems.reduce((t,i)=>t+i.price*i.qty,0)},
 get disc(){return Math.min(Math.max(0,n(this.discount)),this.subtotal)},
 get tax(){return Math.round((this.subtotal-this.disc)*n(this.settings.tax)/100)},
 get total(){return this.subtotal-this.disc+this.tax},
 get quick(){const t=this.total;if(!t)return[];return[...new Set([t,Math.ceil(t/10000)*10000,Math.ceil(t/50000)*50000,Math.ceil(t/100000)*100000])].slice(0,4)},
 addToCart(p){
  const c=this.cart.find(x=>x.id===p.id),have=c?c.qty:0;
  if(have+1>p.stock)return this.toast('Stok '+p.name+' hanya '+p.stock,'err');
  if(c)c.qty++;else this.cart.push({id:p.id,qty:1});
 },
 inc(id){const p=this.products.find(x=>x.id===id);if(p)this.addToCart(p)},
 dec(id){const c=this.cart.find(x=>x.id===id);if(!c)return;c.qty--;if(c.qty<=0)this.removeItem(id)},
 setQty(id,el){
  const p=this.products.find(x=>x.id===id),c=this.cart.find(x=>x.id===id);if(!p||!c)return;
  let q=Math.floor(n(el.value));
  if(q<=0)return this.removeItem(id);
  if(q>p.stock){q=p.stock;this.toast('Stok '+p.name+' hanya '+p.stock,'err')}
  c.qty=q;el.value=q;
 },
 removeItem(id){this.cart=this.cart.filter(c=>c.id!==id)},
 clearCart(){this.cart=[];this.discount='';this.paid='';this.customerId=''},
 scanEnter(){
  const k=this.q.trim().toLowerCase();if(!k)return;
  let p=this.products.find(x=>x.sku.toLowerCase()===k);
  if(!p&&this.filteredProducts.length===1)p=this.filteredProducts[0];
  if(!p)return this.toast('Barang tidak ditemukan','err');
  if(p.stock<=0)return this.toast(p.name+' stok habis','err');
  this.addToCart(p);this.q='';
 },
 checkout(){
  if(!this.cartItems.length)return this.toast('Struk masih kosong','err');
  const total=this.total;let paid=total;
  if(this.method==='Tunai'){paid=n(this.paid);if(paid<total)return this.toast('Uang diterima kurang '+this.rp(total-paid),'err')}
  for(const it of this.cartItems)if(it.qty>it.stock)return this.toast('Stok '+it.name+' hanya '+it.stock,'err');
  const d=new Date(),pre='TRX-'+ymd(d).replace(/-/g,'')+'-';
  const last=Math.max(0,...this.sales.filter(s=>s.no.startsWith(pre)).map(s=>parseInt(s.no.slice(-3))||0));
  const cust=this.customers.find(c=>c.id===this.customerId);
  const sale={id:uid(),no:pre+String(last+1).padStart(3,'0'),date:d.toISOString(),cashier:this.user.name,customerId:cust?cust.id:'',customerName:cust?cust.name:'Umum',
   items:this.cartItems.map(i=>({id:i.id,name:i.name,price:i.price,cost:i.cost,qty:i.qty})),
   subtotal:this.subtotal,discount:this.disc,taxRate:n(this.settings.tax),tax:this.tax,total,method:this.method,paid,change:paid-total};
  this.products=this.products.map(p=>{const it=sale.items.find(i=>i.id===p.id);return it?{...p,stock:p.stock-it.qty}:p});
  this.sales=[sale,...this.sales];this.persist();this.clearCart();this.rcpt=sale;
  this.startLoad();setTimeout(()=>this.endLoad(),400);
  this.toast('Pembayaran berhasil');
 },

 /* ---------- riwayat ---------- */
 get filteredSales(){const k=this.hq.trim().toLowerCase();return this.sales.filter(s=>(!k||s.no.toLowerCase().includes(k)||s.customerName.toLowerCase().includes(k))&&(!this.hd||ymd(new Date(s.date))===this.hd))},
 deleteSale(s){this.ask('Hapus transaksi '+s.no+'? Stok barang akan dikembalikan.',()=>{
  this.products=this.products.map(p=>{const it=s.items.find(i=>i.id===p.id);return it?{...p,stock:p.stock+it.qty}:p});
  this.sales=this.sales.filter(x=>x.id!==s.id);this.persist();this.toast('Transaksi dihapus')})},
 exportCsv(){
  const q=v=>'"'+String(v).replace(/"/g,'""')+'"';
  const rows=[['No. struk','Waktu','Kasir','Pelanggan','Metode','Subtotal','Diskon','Pajak','Total'].map(q).join(',')];
  this.filteredSales.forEach(s=>rows.push([s.no,this.fmtDate(s.date),s.cashier,s.customerName,s.method,s.subtotal,s.discount,s.tax,s.total].map(q).join(',')));
  this.download('riwayat-transaksi.csv','\ufeff'+rows.join('\n'),'text/csv;charset=utf-8');
 },

 /* ---------- laporan ---------- */
 get repSales(){
  if(this.period==='all')return this.sales;
  const now=new Date(),days=this.period==='today'?0:Number(this.period)-1,start=new Date(now.getFullYear(),now.getMonth(),now.getDate()-days);
  return this.sales.filter(s=>new Date(s.date)>=start);
 },
 get repStats(){
  const r=this.repSales;
  return{omzet:r.reduce((t,s)=>t+s.total,0),trx:r.length,
   items:r.reduce((t,s)=>t+s.items.reduce((a,i)=>a+i.qty,0),0),
   laba:r.reduce((t,s)=>t+s.items.reduce((a,i)=>a+(i.price-i.cost)*i.qty,0)-s.discount,0)};
 },
 get repDays(){
  const len=this.period==='30'?30:7,out=[],now=new Date();
  for(let i=len-1;i>=0;i--){
   const d=new Date(now.getFullYear(),now.getMonth(),now.getDate()-i),key=ymd(d);
   out.push({key,label:len===30?String(d.getDate()):d.getDate()+'/'+(d.getMonth()+1),total:this.sales.filter(s=>ymd(new Date(s.date))===key).reduce((t,s)=>t+s.total,0)});
  }
  const max=Math.max(1,...out.map(o=>o.total));
  return out.map(o=>({...o,pct:Math.round(o.total/max*80)}));
 },
 get topProducts(){
  const m={};this.repSales.forEach(s=>s.items.forEach(i=>{m[i.name]=m[i.name]||{name:i.name,qty:0,rev:0};m[i.name].qty+=i.qty;m[i.name].rev+=i.qty*i.price}));
  return Object.values(m).sort((a,b)=>b.qty-a.qty).slice(0,5);
 },
 get byMethod(){
  const m={};this.repSales.forEach(s=>{m[s.method]=m[s.method]||{name:s.method,count:0,total:0};m[s.method].count++;m[s.method].total+=s.total});
  return Object.values(m).sort((a,b)=>b.total-a.total);
 },

 /* ---------- pengaturan & data ---------- */
 saveSettings(){
  const f=this.sf,tax=n(f.tax);
  if(!(f.storeName||'').trim())return this.toast('Nama toko wajib diisi','err');
  if(tax<0||tax>100)return this.toast('Pajak harus antara 0 dan 100','err');
  this.settings={storeName:f.storeName.trim(),address:(f.address||'').trim(),phone:(f.phone||'').trim(),tax,footer:(f.footer||'').trim()};
  this.persist();this.toast('Pengaturan disimpan');
 },
 backup(){this.download('cadangan-kasirku-'+ymd(new Date())+'.json',JSON.stringify({products:this.products,customers:this.customers,sales:this.sales,settings:this.settings}),'application/json')},
 restore(e){
  const file=e.target.files[0];e.target.value='';if(!file)return;
  const r=new FileReader();
  r.onload=()=>{try{
   const d=JSON.parse(r.result);if(!Array.isArray(d.products)||!Array.isArray(d.sales)||!Array.isArray(d.customers))throw 0;
   this.ask('Pulihkan data dari file ini? Data toko saat ini akan diganti.',()=>{
    this.products=d.products;this.customers=d.customers;this.sales=d.sales;if(d.settings)this.settings=d.settings;this.sf={...this.settings};this.cart=[];this.persist();this.toast('Data berhasil dipulihkan')},'Pulihkan');
  }catch(err){this.toast('File cadangan tidak valid','err')}};
  r.readAsText(file);
 },
 wipe(){this.ask('Hapus semua barang, pelanggan, dan transaksi? Tindakan ini tidak bisa dibatalkan.',()=>{
  this.products=[];this.customers=[];this.sales=[];this.cart=[];this.persist();this.toast('Semua data toko dihapus')},'Hapus semua')}
}}